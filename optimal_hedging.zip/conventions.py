# -*- coding: utf-8 -*-
"""
Created on Sat Jul  3 14:08:37 2021

@author: oleg_
"""

def T_conv(T_days):
        T_years = T_days / 365
        return T_years
    